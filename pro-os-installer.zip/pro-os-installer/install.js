#!/usr/bin/env node
/**
 * Pro OS Installer
 * Sets up a basic Pro OS project with bootloader.
 * Usage: node install.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const INSTALL_DIR = path.join(process.cwd(), 'Pro-OS');

console.log('=== Pro OS Installer v0.1 ===');
console.log('Creating safer hobby OS project structure...\n');

// Create directories
const dirs = [
  INSTALL_DIR,
  path.join(INSTALL_DIR, 'boot'),
  path.join(INSTALL_DIR, 'src'),
  path.join(INSTALL_DIR, 'docs')
];

dirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log('Created:', dir);
  }
});

// Bootloader source
const bootAsm = `; Pro OS Bootloader (16-bit real mode)
; Build: nasm -f bin boot.asm -o boot.bin

[org 0x7c00]
[bits 16]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    mov ah, 0x00
    mov al, 0x03
    int 0x10

    mov si, msg
    call print_string

    jmp $

print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    mov bh, 0x00
    int 0x10
    jmp print_string
.done:
    ret

msg db 'Pro OS Bootloader v0.1 - Safer OS Starting...', 0x0D, 0x0A, 0

times 510 - ($ - $$) db 0
dw 0xAA55
`;

fs.writeFileSync(path.join(INSTALL_DIR, 'boot', 'boot.asm'), bootAsm);
console.log('Created boot/boot.asm');

// Basic README
const readme = `# Pro OS

Safer hobby operating system.

## Install / Build
1. Run this installer: \`node install.js\`
2. Install nasm and QEMU
3. \`cd Pro-OS/boot && nasm -f bin boot.asm -o boot.bin\`
4. \`qemu-system-x86_64 -drive format=raw,file=boot.bin\`

## Status
Early bootloader only. Kernel coming soon.
`;

fs.writeFileSync(path.join(INSTALL_DIR, 'README.md'), readme);
console.log('Created README.md');

// Simple kernel stub (placeholder)
const kernelStub = `// Future Rust/C kernel entry will go here
console.log('Pro OS kernel placeholder');
`;

fs.writeFileSync(path.join(INSTALL_DIR, 'src', 'kernel.js'), kernelStub);
console.log('Created src/kernel.js (placeholder)');

console.log('\\n=== Installation complete! ===');
console.log('Project created in:', INSTALL_DIR);
console.log('Next: Install nasm + QEMU, then build the bootloader.');
