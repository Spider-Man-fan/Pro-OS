@echo off
title Pro OS - Gigabytes
color 0B
cls

echo.
echo  ========================================
echo         Pro OS Storage (Gigabytes)
echo  ========================================
echo.

echo Current disk space:
echo.

for /f "tokens=1-3" %%a in ('wmic logicaldisk get size^,freespace^,caption') do (
    echo %%a  %%b  %%c
)

echo.
echo ----- In Gigabytes -----
powershell -Command "Get-PSDrive -PSProvider FileSystem | Select-Object Name, @{N='Used(GB)';E={[math]::Round($_.Used/1GB,2)}}, @{N='Free(GB)';E={[math]::Round($_.Free/1GB,2)}}, @{N='Total(GB)';E={[math]::Round(($_.Used+$_.Free)/1GB,2)}} | Format-Table -AutoSize"

echo.
echo Digital SD Card target: 32 GB
echo.
pause
