@echo off
title Create Digital SD Card (GB)
echo Creating virtual SD card...
echo Note: Creating a full multi-GB file may take time and disk space.
echo.
set /p sizegb="Enter size in GB (example: 1): "
set /a sizemb=%sizegb%*1024
echo Creating %sizegb% GB (%sizemb% MB) file...
fsutil file createnew ProOS-SDCard-%sizegb%GB.img %sizemb%000000
echo Done: ProOS-SDCard-%sizegb%GB.img
pause
