# Pro OS Kernel

Basic safer kernel for Pro OS (Rust, no_std).

## Current features
- Kernel entry (`_start`)
- Writes a message to VGA text mode
- Infinite loop (stable)

## Build (requires nightly Rust + bootimage or custom linker)
```bash
rustup default nightly
cargo build --release
```

## Integration with bootloader
The bootloader loads this kernel and jumps to `_start`.

Next steps: memory management, interrupts, drivers.
