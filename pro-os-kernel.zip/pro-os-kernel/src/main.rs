#![no_std]
#![no_main]

use core::panic::PanicInfo;

/// Kernel entry point
#[no_mangle]
pub extern "C" fn _start() -> ! {
    // Simple VGA text mode output (works after bootloader)
    let vga = 0xb8000 as *mut u8;
    let msg = b"Pro OS Kernel v0.1 - Safer OS Running!";

    for (i, &byte) in msg.iter().enumerate() {
        unsafe {
            *vga.offset(i as isize * 2) = byte;
            *vga.offset(i as isize * 2 + 1) = 0x0f; // white on black
        }
    }

    // Hang
    loop {}
}

/// Panic handler required for no_std
#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}
