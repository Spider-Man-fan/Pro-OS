# SELinux Policy (Pro OS)

Mandatory Access Control for stronger isolation.

## Goals
- Least privilege for all processes
- Separate domains for apps, system services, and kernel
- Deny-by-default

## Starter policy ideas
- untrusted_app domain
- system_server restrictions
- no raw socket access for apps
