# Secure / Verified Boot

## Goals
- Chain of trust from bootloader → kernel → system
- Signed images only
- Rollback protection

## Components
- Bootloader verifies kernel signature
- Kernel verifies system partitions
