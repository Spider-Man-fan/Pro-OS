# Hardened Memory Allocator

Inspired by GrapheneOS hardened_malloc.

## Protections
- Guard pages
- Randomization
- Quarantine for freed memory
- Detection of overflows
