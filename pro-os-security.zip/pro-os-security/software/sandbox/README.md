# Application Sandbox

Strong process isolation (inspired by Android/GrapheneOS).

## Features
- Per-app UID
- Seccomp-bpf filters
- Namespace isolation
- No ambient authority
