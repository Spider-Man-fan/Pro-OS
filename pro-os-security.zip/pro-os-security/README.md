# Pro OS Security

Software + Hardware security additions for the safer Pro OS project.

## Software
- sepolicy/          - SELinux policies
- sandbox/           - App isolation
- secure-boot/       - Verified boot chain
- hardened-malloc/   - Memory safety allocator

## Hardware
- tpm/               - Trusted Platform Module
- secure-element/    - Secure Element / StrongBox
- verified-boot/     - Hardware verified boot

Drop these folders into the GrapheneOS-style structure:
- software/* → system/sepolicy, frameworks, etc.
- hardware/* → hardware/ or device/
