# Secure Element / StrongBox

## Uses
- Hardware-backed keystore
- Biometric authentication
- Payment / credential storage
