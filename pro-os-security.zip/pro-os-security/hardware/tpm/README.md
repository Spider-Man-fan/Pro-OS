# TPM (Trusted Platform Module)

## Uses
- Secure key storage
- Measured boot
- Remote attestation
- Disk encryption keys
