# Verified Boot (AVB)

## Features
- Android Verified Boot style
- dm-verity
- Rollback protection
- Custom key support (user-controlled)
