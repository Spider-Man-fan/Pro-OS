# Hardware Security Components

Pro OS aims to support modern hardware security features.
