# SystemInfoHandeling - Pro OS
# PowerShell version

function Show-Menu {
    Clear-Host
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host "      SystemInfoHandeling" -ForegroundColor Yellow
    Write-Host "      Pro OS System Information Tool" -ForegroundColor Cyan
    Write-Host "==============================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1. Full System Information"
    Write-Host "2. CPU and Memory"
    Write-Host "3. Disk Drives (GB)"
    Write-Host "4. Network"
    Write-Host "5. Export Report"
    Write-Host "6. Exit"
    Write-Host ""
}

do {
    Show-Menu
    $c = Read-Host "Select"
    switch ($c) {
        "1" { systeminfo; Pause }
        "2" { 
            Get-CimInstance Win32_Processor | Select Name, NumberOfCores, MaxClockSpeed
            Get-CimInstance Win32_PhysicalMemory | Select Manufacturer, Speed, @{N='CapacityGB';E={$_.Capacity/1GB}}
            Pause 
        }
        "3" {
            Get-PSDrive -PSProvider FileSystem | Select Name, 
                @{N='TotalGB';E={[math]::Round(($_.Used+$_.Free)/1GB,2)}}, 
                @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}
            Pause
        }
        "4" { ipconfig /all; Pause }
        "5" { 
            systeminfo | Out-File SystemInfoHandeling-Report.txt
            Write-Host "Saved to SystemInfoHandeling-Report.txt" -ForegroundColor Green
            Pause 
        }
        "6" { break }
    }
} while ($true)
