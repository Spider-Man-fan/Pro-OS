@echo off
title SystemInfoHandeling - Pro OS
color 0B
cls

:menu
echo.
echo  ==============================================
echo       SystemInfoHandeling
echo       Pro OS System Information Tool
echo  ==============================================
echo.
echo   1. Full System Information
echo   2. CPU and Memory
echo   3. Disk Drives (Gigabytes)
echo   4. Network Adapters
echo   5. Operating System Details
echo   6. BIOS / UEFIH Info
echo   7. Export Report to File
echo   8. Exit
echo.
set /p choice="Select option: "

if "%choice%"=="1" goto full
if "%choice%"=="2" goto cpu
if "%choice%"=="3" goto disk
if "%choice%"=="4" goto network
if "%choice%"=="5" goto os
if "%choice%"=="6" goto bios
if "%choice%"=="7" goto export
if "%choice%"=="8" exit
goto menu

:full
echo.
systeminfo
echo.
pause
goto menu

:cpu
echo.
echo ===== CPU =====
wmic cpu get name,numberofcores,maxclockspeed
echo.
echo ===== Memory =====
wmic memorychip get capacity,speed,manufacturer
echo.
pause
goto menu

:disk
echo.
echo ===== Disk Drives =====
wmic logicaldisk get caption,size,freespace,filesystem
echo.
powershell -Command "Get-PSDrive -PSProvider FileSystem | Select Name, @{N='TotalGB';E={[math]::Round(($_.Used+$_.Free)/1GB,2)}}, @{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}"
echo.
pause
goto menu

:network
echo.
ipconfig /all
echo.
pause
goto menu

:os
echo.
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"OS Manufacturer" /C:"System Type" /C:"Total Physical Memory"
echo.
pause
goto menu

:bios
echo.
echo ===== BIOS / UEFIH =====
wmic bios get manufacturer,name,version,releasedate
echo.
echo UEFIH Status: Custom Pro OS BIOS
echo.
pause
goto menu

:export
echo Exporting report...
systeminfo > SystemInfoHandeling-Report.txt
echo Disk: >> SystemInfoHandeling-Report.txt
wmic logicaldisk get caption,size,freespace >> SystemInfoHandeling-Report.txt
echo.
echo Report saved as SystemInfoHandeling-Report.txt
pause
goto menu
