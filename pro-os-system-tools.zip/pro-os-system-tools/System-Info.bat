@echo off
title Pro OS System Info
color 0B
echo ===== Pro OS System Information =====
echo.
systeminfo
echo.
echo ===== Disk Space =====
wmic logicaldisk get size,freespace,caption
echo.
pause
