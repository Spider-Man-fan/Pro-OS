@echo off
title Pro OS System Tools
color 0E
cls

:menu
echo.
echo  ========================================
echo      Pro OS System Tools
echo  ========================================
echo.
echo   1. Disk Cleanup
echo   2. Check Disk
echo   3. Task Manager
echo   4. Resource Monitor
echo   5. Event Viewer
echo   6. Services
echo   7. Device Manager
echo   8. Registry Editor
echo   9. Command Prompt
echo   0. Back
echo.
set /p choice="Select tool: "

if "%choice%"=="1" cleanmgr
if "%choice%"=="2" chkdsk
if "%choice%"=="3" taskmgr
if "%choice%"=="4" resmon
if "%choice%"=="5" eventvwr
if "%choice%"=="6" services.msc
if "%choice%"=="7" devmgmt.msc
if "%choice%"=="8" regedit
if "%choice%"=="9" cmd
if "%choice%"=="0" exit
pause
goto menu
