@echo off
title Pro OS System Settings
color 0A
cls

:menu
echo.
echo  ========================================
echo     Pro OS System Settings
echo  ========================================
echo.
echo   1. Display Settings
echo   2. Sound Settings
echo   3. Network Info
echo   4. Power Options
echo   5. User Accounts
echo   6. System Info
echo   7. Open System Tools
echo   8. Exit
echo.
set /p choice="Select: "

if "%choice%"=="1" goto display
if "%choice%"=="2" goto sound
if "%choice%"=="3" goto network
if "%choice%"=="4" goto power
if "%choice%"=="5" goto users
if "%choice%"=="6" goto sysinfo
if "%choice%"=="7" goto tools
if "%choice%"=="8" exit
goto menu

:display
echo Opening Display Settings...
start ms-settings:display
pause
goto menu

:sound
echo Opening Sound Settings...
start ms-settings:sound
pause
goto menu

:network
echo Network Information:
ipconfig
pause
goto menu

:power
echo Opening Power Options...
powercfg.cpl
pause
goto menu

:users
echo Opening User Accounts...
control userpasswords2
pause
goto menu

:sysinfo
echo System Information:
systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type" /C:"Total Physical Memory"
pause
goto menu

:tools
call System-Tools.bat
goto menu
