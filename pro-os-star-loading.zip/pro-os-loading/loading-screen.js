// Pro OS Star Loading Screen
// Call showStarLoading() after download/install completes

function showStarLoading(containerId = 'loading-container') {
  const container = document.getElementById(containerId) || document.body;
  container.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;background:#0a0a0f;color:#fff;font-family:system-ui;">
      <div style="width:100px;height:100px;animation:spin 2s linear infinite;">
        <svg viewBox="0 0 24 24" style="width:100%;height:100%;fill:#ffd700;filter:drop-shadow(0 0 12px #ffd700);">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
        </svg>
      </div>
      <h2 style="margin-top:20px;letter-spacing:2px;">Pro OS</h2>
      <p style="color:#aaa;margin-top:10px;">Loading your safer OS...</p>
    </div>
    <style>
      @keyframes spin { to { transform: rotate(360deg); } }
    </style>
  `;
}

// Example usage after download:
// showStarLoading();
