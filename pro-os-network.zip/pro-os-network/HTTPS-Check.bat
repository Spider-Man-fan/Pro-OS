@echo off
title Pro OS HTTPS Check
echo Testing HTTPS connectivity...
echo.
powershell -Command "try { Invoke-WebRequest -Uri https://www.google.com -UseBasicParsing -TimeoutSec 10 | Select-Object StatusCode, StatusDescription } catch { Write-Host 'HTTPS test failed' }"
echo.
echo Certificate check enabled in Network.conf
pause
