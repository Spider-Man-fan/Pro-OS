@echo off
title Pro OS Wi-Fi
set /p ssid="Enter Wi-Fi SSID: "
set /p pass="Enter Password: "
echo Connecting to %ssid%...
netsh wlan connect name="%ssid%"
echo.
netsh wlan show interfaces
pause
