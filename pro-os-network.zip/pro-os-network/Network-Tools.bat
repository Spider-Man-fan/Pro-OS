@echo off
title Pro OS Network Tools
color 0B
cls

:menu
echo.
echo  ========================================
echo      Pro OS Network Tools
echo   Proxy / HTTPS / Wi-Fi / Adapter
echo  ========================================
echo.
echo   1. Show Network Adapters
echo   2. Show IP Configuration
echo   3. Wi-Fi Status
echo   4. Test Internet Connection
echo   5. Flush DNS
echo   6. Reset Network Adapter
echo   7. Show Proxy Settings
echo   8. Exit
echo.
set /p choice="Select: "

if "%choice%"=="1" goto adapters
if "%choice%"=="2" goto ipconfig
if "%choice%"=="3" goto wifi
if "%choice%"=="4" goto internet
if "%choice%"=="5" goto flush
if "%choice%"=="6" goto reset
if "%choice%"=="7" goto proxy
if "%choice%"=="8" exit
goto menu

:adapters
echo.
echo ===== Network Adapters =====
wmic nic get name,macaddress,netenabled
echo.
pause
goto menu

:ipconfig
echo.
ipconfig /all
echo.
pause
goto menu

:wifi
echo.
echo ===== Wi-Fi Status =====
netsh wlan show interfaces
echo.
netsh wlan show profiles
echo.
pause
goto menu

:internet
echo.
echo Testing internet connection...
ping -n 4 8.8.8.8
echo.
ping -n 2 google.com
echo.
pause
goto menu

:flush
echo Flushing DNS...
ipconfig /flushdns
echo Done.
pause
goto menu

:reset
echo Resetting network (may require admin)...
netsh winsock reset
netsh int ip reset
echo Restart required.
pause
goto menu

:proxy
echo.
echo ===== Proxy Settings =====
netsh winhttp show proxy
echo.
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable 2>nul
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyServer 2>nul
echo.
pause
goto menu
