# Pro OS Network Tools
Write-Host "Pro OS Network - Proxy/HTTPS/Wi-Fi/Adapter" -ForegroundColor Cyan

Write-Host "`n=== Adapters ===" -ForegroundColor Yellow
Get-NetAdapter | Select Name, Status, LinkSpeed, MacAddress | Format-Table -AutoSize

Write-Host "`n=== Wi-Fi ===" -ForegroundColor Yellow
netsh wlan show interfaces

Write-Host "`n=== Internet Test ===" -ForegroundColor Yellow
Test-Connection 8.8.8.8 -Count 2

Write-Host "`n=== Proxy ===" -ForegroundColor Yellow
Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" | Select ProxyEnable, ProxyServer
