@echo off
title .Exea - Installation Hardware Protection
color 0A
cls

echo.
echo  ========================================
echo            . E x e a
echo   Installation Hardware Protection
echo  ========================================
echo.

echo [1] Checking CPU...
wmic cpu get name
echo.

echo [2] Checking Memory...
wmic computersystem get totalphysicalmemory
echo.

echo [3] Checking Disks...
wmic diskdrive get model,status,size
echo.

echo [4] Checking BIOS / UEFI...
wmic bios get manufacturer,version
echo.

echo [5] Secure Boot / TPM status (if available)...
powershell -Command "try { Confirm-SecureBootUEFI } catch { Write-Host 'Secure Boot info not available' }"
echo.

echo ========================================
echo  Hardware protection check complete.
echo  Safe to proceed with installation if no errors.
echo ========================================
pause
