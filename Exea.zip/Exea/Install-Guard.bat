@echo off
echo .Exea Install Guard active
echo Verifying hardware before Pro OS installation...
call Hardware-Protection.bat
echo Hardware OK. Proceeding with protected install.
