' Pro OS Digital SD Card Save Tool
' Creates and manages a virtual SD card file for Pro OS
' Double-click to run on Windows

Option Explicit

Dim fso, shell, sdFile, sdPath, action, data

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

sdPath = shell.CurrentDirectory & "\ProOS-SDCard.img"
sdFile = "ProOS-SDCard.img"

WScript.Echo "=== Pro OS Digital SD Card ==="
WScript.Echo "Virtual SD card: " & sdFile
WScript.Echo ""

If Not fso.FileExists(sdPath) Then
    ' Create a new virtual SD card (1 MB placeholder)
    Dim stream
    Set stream = fso.CreateTextFile(sdPath, True)
    stream.Write "PRO-OS-SD-CARD-v1" & String(1024 * 1024 - 16, Chr(0))
    stream.Close
    WScript.Echo "Created new digital SD card: " & sdFile
Else
    WScript.Echo "Existing SD card found: " & sdFile
End If

' Simple menu
action = InputBox("What do you want to do?" & vbCrLf & vbCrLf & _
                  "1 = Show SD card info" & vbCrLf & _
                  "2 = Save a text note to SD card" & vbCrLf & _
                  "3 = Read saved notes" & vbCrLf & _
                  "4 = Format (reset) SD card", _
                  "Pro OS SD Card", "1")

Select Case action
    Case "1"
        Dim size
        size = fso.GetFile(sdPath).Size
        WScript.Echo "SD Card Size: " & size & " bytes"
        WScript.Echo "Location: " & sdPath
        
    Case "2"
        data = InputBox("Enter text to save on the digital SD card:", "Save to SD")
        If data <> "" Then
            Dim noteFile
            noteFile = shell.CurrentDirectory & "\sd-notes.txt"
            Dim ts
            Set ts = fso.OpenTextFile(noteFile, 8, True) ' append
            ts.WriteLine Now & " - " & data
            ts.Close
            WScript.Echo "Saved to digital SD notes!"
        End If
        
    Case "3"
        Dim notesPath
        notesPath = shell.CurrentDirectory & "\sd-notes.txt"
        If fso.FileExists(notesPath) Then
            Dim content
            Set content = fso.OpenTextFile(notesPath, 1)
            WScript.Echo "=== Saved Notes on SD ===" & vbCrLf & content.ReadAll
            content.Close
        Else
            WScript.Echo "No notes saved yet."
        End If
        
    Case "4"
        If MsgBox("Format the digital SD card? This will reset it.", vbYesNo, "Confirm") = vbYes Then
            fso.DeleteFile sdPath
            Set stream = fso.CreateTextFile(sdPath, True)
            stream.Write "PRO-OS-SD-CARD-v1" & String(1024 * 1024 - 16, Chr(0))
            stream.Close
            If fso.FileExists(shell.CurrentDirectory & "\sd-notes.txt") Then
                fso.DeleteFile shell.CurrentDirectory & "\sd-notes.txt"
            End If
            WScript.Echo "SD card formatted."
        End If
        
    Case Else
        WScript.Echo "Cancelled."
End Select

WScript.Echo vbCrLf & "Done."
