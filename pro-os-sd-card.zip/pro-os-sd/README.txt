Pro OS Digital SD Card (VBS)

How to use:
1. Double-click SD-Card-Save.vbs
2. It creates ProOS-SDCard.img (virtual SD card)
3. Use the menu to save notes, read them, or format

This is a simple digital save system for the Pro OS project.
