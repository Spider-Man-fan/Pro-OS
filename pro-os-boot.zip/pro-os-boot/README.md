# Pro OS Bootloader

Simple 16-bit BIOS bootloader for Pro OS.

## Build
```bash
nasm -f bin boot.asm -o boot.bin
```

## Test in QEMU
```bash
qemu-system-x86_64 -drive format=raw,file=boot.bin
```

## Next steps
- Load a kernel from disk
- Switch to protected mode
- Hand off to Rust/C kernel
