; Pro OS Bootloader (16-bit real mode)
; Assembles with: nasm -f bin boot.asm -o boot.bin
; Then pad to 512 bytes and use as boot sector.

[org 0x7c00]
[bits 16]

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    ; Clear screen (optional simple)
    mov ah, 0x00
    mov al, 0x03
    int 0x10

    ; Print message
    mov si, msg
    call print_string

    ; Hang (in a real OS you would load the kernel here)
    jmp $

print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0e
    mov bh, 0x00
    int 0x10
    jmp print_string
.done:
    ret

msg db 'Pro OS Bootloader v0.1 - Safer OS Starting...', 0x0D, 0x0A, 0

; Pad to 510 bytes and add boot signature
times 510 - ($ - $$) db 0
dw 0xAA55
