# Pro OS ASAP FIX
Write-Host "========================================" -ForegroundColor Red
Write-Host "          A S A P   F I X" -ForegroundColor Yellow
Write-Host "   Pro OS Emergency Configuration" -ForegroundColor Red
Write-Host "========================================" -ForegroundColor Red
Write-Host ""

Write-Host "[1] Clearing temp files..." -ForegroundColor Cyan
Remove-Item -Path $env:TEMP\* -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "[2] Flushing DNS..." -ForegroundColor Cyan
ipconfig /flushdns | Out-Null

Write-Host "[3] Network reset (partial)..." -ForegroundColor Cyan
# netsh commands require admin

Write-Host "[4] Reading ASAP-FIX.conf..." -ForegroundColor Cyan
if (Test-Path "ASAP-FIX.conf") {
    Get-Content "ASAP-FIX.conf"
}

Write-Host ""
Write-Host "ASAP FIX applied. Restart recommended." -ForegroundColor Green
Pause
