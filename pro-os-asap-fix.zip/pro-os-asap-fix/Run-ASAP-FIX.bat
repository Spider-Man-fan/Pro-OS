@echo off
title Pro OS - ASAP FIX
color 0C
cls

echo.
echo  ========================================
echo           A S A P   F I X
echo      Pro OS Emergency Configuration
echo  ========================================
echo.

echo Applying ASAP fixes...
echo.

echo [1/5] Clearing temporary files...
del /q /f /s %TEMP%\*.* 2>nul
echo Done.

echo [2/5] Flushing DNS...
ipconfig /flushdns
echo Done.

echo [3/5] Resetting network stack...
netsh winsock reset
netsh int ip reset
echo Done. (Restart required)

echo [4/5] Checking disk...
echo Scheduling chkdsk on next boot...
echo Y | chkdsk C: /f
echo Done.

echo [5/5] Loading ASAP-FIX.conf...
type ASAP-FIX.conf
echo.

echo ========================================
echo   ASAP FIX complete.
echo   Restart recommended.
echo ========================================
pause
