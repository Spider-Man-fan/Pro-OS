@echo off
title Pro OS - Install Without Warning (.bxty)
color 0A
cls

echo.
echo  ========================================
echo         . b x t y
echo    Install Without Warning
echo  ========================================
echo.

if exist ProOS.bxty (
    echo Found ProOS.bxty - Silent install mode enabled.
    type ProOS.bxty
    echo.
    echo Applying silent flags...
) else (
    echo No .bxty file found. Using default silent mode.
)

echo.
echo [Silent Install Active]
echo - No warning dialogs
echo - No confirmation prompts
echo - Auto-accept
echo - Quiet mode
echo.

echo Installation proceeding without warnings...
echo Done.
pause
