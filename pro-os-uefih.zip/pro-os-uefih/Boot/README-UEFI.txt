Place your UEFI applications (.efi) here.

Example:
- bootx64.efi
- ProOS-loader.efi
- UEFIH-setup.efi
