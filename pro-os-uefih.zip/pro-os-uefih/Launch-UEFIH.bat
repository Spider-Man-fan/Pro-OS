@echo off
title UEFIH - Pro OS BIOS
color 0A
cls
echo.
echo   ========================================
echo              U E F I H
echo         Pro OS Custom BIOS / UEFI
echo   ========================================
echo.
echo   Version 0.1
echo   Secure Boot: Enabled
echo   Default OS: Pro OS
echo.
echo   Boot options:
echo   1. Pro OS
echo   2. UEFIH Setup
echo   3. Exit
echo.
set /p choice="Select: "
if "%choice%"=="1" echo Booting Pro OS...
if "%choice%"=="2" echo Opening UEFIH Setup...
if "%choice%"=="3" exit
pause
