# Star Icon Pack for GitHub

A simple collection of star icons in SVG format, suitable for use in GitHub projects, READMEs, websites, or applications.

## Included Icons

- `star-filled.svg` - Solid filled star
- `star-outline.svg` - Outline star
- `star-half.svg` - Half-filled star

## Usage

These SVGs use `currentColor` so they inherit the text color of their parent element. Perfect for dark/light mode support.

### Example HTML
```html
<img src="star-filled.svg" alt="Star" width="24" height="24">
```

Or inline:
```html
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24" height="24">
  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
</svg>
```

## License

Free to use in any project, including commercial. No attribution required.
