@echo off
title Pro OS - Star App Structure
color 0E
cls

echo.
echo            ★
echo           /|\
echo          / | \
echo         /  |  \
echo        /   |   \
echo       /____|____\
echo            |
echo         Pro OS
echo.

echo Creating Pro OS app structure...
echo.

set ROOT=%~dp0Pro-OS

mkdir "%ROOT%\frameworks\base" 2>nul
mkdir "%ROOT%\frameworks\native" 2>nul
mkdir "%ROOT%\packages\apps\Settings" 2>nul
mkdir "%ROOT%\packages\apps\Launcher" 2>nul
mkdir "%ROOT%\packages\apps\Files" 2>nul
mkdir "%ROOT%\packages\apps\Notes" 2>nul
mkdir "%ROOT%\system\core" 2>nul
mkdir "%ROOT%\system\sepolicy" 2>nul
mkdir "%ROOT%\hardware" 2>nul
mkdir "%ROOT%\kernel" 2>nul
mkdir "%ROOT%\bootable" 2>nul
mkdir "%ROOT%\device\proos\generic" 2>nul
mkdir "%ROOT%\vendor" 2>nul
mkdir "%ROOT%\build" 2>nul
mkdir "%ROOT%\external" 2>nul

echo.
echo     ★  Structure created  ★
echo.
echo          frameworks
echo         /    |    \
echo   packages  system  hardware
echo      |        |        |
echo    apps     core     kernel
echo      |        |
echo   Settings  sepolicy
echo.

echo Done! Folders are in: %ROOT%
echo.
pause
