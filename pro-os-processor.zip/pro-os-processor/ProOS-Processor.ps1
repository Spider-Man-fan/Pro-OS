# Pro OS Processing System (PowerShell)
# Run: powershell -ExecutionPolicy Bypass -File ProOS-Processor.ps1

function Show-Menu {
    Clear-Host
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  Pro OS Processing System v1.0" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "1. Uppercase a text file"
    Write-Host "2. Count lines and words"
    Write-Host "3. Batch rename files"
    Write-Host "4. List all files in folder"
    Write-Host "5. Exit"
    Write-Host ""
}

do {
    Show-Menu
    $choice = Read-Host "Choose option"
    switch ($choice) {
        "1" {
            $file = Read-Host "File path"
            if (Test-Path $file) {
                (Get-Content $file).ToUpper() | Set-Content "$file.processed.txt"
                Write-Host "Saved as $file.processed.txt" -ForegroundColor Green
            } else { Write-Host "File not found" -ForegroundColor Red }
            Pause
        }
        "2" {
            $file = Read-Host "File path"
            if (Test-Path $file) {
                $content = Get-Content $file
                $lines = $content.Count
                $words = ($content | Measure-Object -Word).Words
                Write-Host "Lines: $lines | Words: $words" -ForegroundColor Green
            }
            Pause
        }
        "3" {
            $folder = Read-Host "Folder path"
            $prefix = Read-Host "Prefix"
            $i = 1
            Get-ChildItem $folder -File | ForEach-Object {
                Rename-Item $_.FullName -NewName "$prefix-$i$($_.Extension)"
                $i++
            }
            Write-Host "Done" -ForegroundColor Green
            Pause
        }
        "4" {
            $folder = Read-Host "Folder path"
            Get-ChildItem $folder -Recurse -File | Select-Object FullName | Out-File "$folder\file-list.txt"
            Write-Host "Saved to file-list.txt" -ForegroundColor Green
            Pause
        }
        "5" { break }
    }
} while ($true)
