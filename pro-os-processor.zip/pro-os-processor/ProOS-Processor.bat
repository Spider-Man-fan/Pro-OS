@echo off
title Pro OS Processing System
color 0B
cls

:menu
echo.
echo  ========================================
echo   Pro OS Processing System v1.0
echo  ========================================
echo.
echo   1. Process Text File (uppercase)
echo   2. Count Lines / Words in File
echo   3. Batch Rename Files
echo   4. Clean Temporary Files
echo   5. Process Folder (list all files)
echo   6. Exit
echo.
set /p choice="Choose an option: "

if "%choice%"=="1" goto textupper
if "%choice%"=="2" goto count
if "%choice%"=="3" goto rename
if "%choice%"=="4" goto clean
if "%choice%"=="5" goto listfolder
if "%choice%"=="6" goto end
goto menu

:textupper
set /p file="Enter text file path: "
if not exist "%file%" (
    echo File not found.
    pause
    goto menu
)
echo Processing...
powershell -Command "(Get-Content '%file%').ToUpper() | Set-Content '%file%.processed.txt'"
echo Done! Saved as %file%.processed.txt
pause
goto menu

:count
set /p file="Enter file path: "
if not exist "%file%" (
    echo File not found.
    pause
    goto menu
)
for /f %%a in ('find /c /v "" ^< "%file%"') do set lines=%%a
echo Lines: %lines%
pause
goto menu

:rename
set /p folder="Enter folder path: "
set /p prefix="Enter prefix for files: "
cd /d "%folder%"
set n=1
for %%f in (*.*) do (
    ren "%%f" "%prefix%-!n!%%~xf"
    set /a n+=1
)
echo Rename complete.
pause
goto menu

:clean
echo Cleaning temp files...
del /q /s %TEMP%\*.tmp 2>nul
del /q /s %TEMP%\*.log 2>nul
echo Done.
pause
goto menu

:listfolder
set /p folder="Enter folder path: "
dir /s /b "%folder%" > "%folder%\file-list.txt"
echo File list saved to file-list.txt
pause
goto menu

:end
echo Exiting Pro OS Processor.
exit
